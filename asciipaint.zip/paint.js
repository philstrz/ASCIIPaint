window.addEventListener("load", setup);
window.addEventListener("keypress", function(event) {
    press(event.key);
})
window.addEventListener("wheel", function(event) {
    scroll(event);
    return false;
})

var canvas = null;
var scale = 100;

function setup() {
    canvas = document.getElementById("canvas");
}

function press(key) {
    console.log(key);
}

function scroll(event) {
    console.log(event.deltaY);
    if (event.deltaY < 0) {
        scaleCanvas(5);
    } else {
        scaleCanvas(-5);
    }
}

function scaleCanvas(amount) {
    scale += amount;
    canvas.style.transform = "scale(" + scale + "%)";
}